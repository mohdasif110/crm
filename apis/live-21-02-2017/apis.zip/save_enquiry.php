<?php
require_once 'db_connection.php';

$post 		=	json_decode($_POST['enquery'],true);


if(isset($post['key']) && $post['key']=='bmh_enquery'){

	$jsonPost			=	json_encode($post['postEnqueryData']);	
	$insertLead 		=	"insert into crm_enquiry_capture set enquiry_from='bmh', leadvalujson='".$jsonPost."',created_time='".time()."'";
	$result 			=   mysql_query($insertLead);
	echo json_encode(array('action'=>'success','message'=>'lead has been saved'));
	
 }else{
	
	echo json_encode(array('action'=>'error','message'=>'fail'));

}

?>

