<?php
require_once 'db_connection.php';

$selectEnquiry 		=	"select *from crm_enquiry_capture where syn_in_crm='0' order by created_time desc";
$result = mysql_query($selectEnquiry);
$rows = mysql_num_rows($result);
$enquery = array();

if($rows > 0){
	
	while($row = mysql_fetch_assoc($result)){
		
		$row['leadJson'] 	=		json_decode($row['leadvalujson']);
		unset($row['leadvalujson']);
		array_push($enquery,$row);
		$selectupdate 		=	"update crm_enquiry_capture set syn_in_crm=1,syn_marker_new=1";
		mysql_query($selectupdate);
	
	}
	
}

echo json_encode($enquery,true);

?>

