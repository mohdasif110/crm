/**
 * @version 1.0
 * script.js 
 * main script file for common functionality in application
 * @author Abhishek Agrawal
 */

jQuery.noConflict();
(function ($){
    
                $(document).ready(function (){
                    
                    // Slide left nav list down or up 
                    $('.left-nav-expander').click(function (e){
                       
                        e.stopPropagation(); // Stop propagating event
                        
                        var slide_direction  = $('#left-navigation-block').attr('data-slide');
                        switch(slide_direction){
                            
                            case 'down':
                                $('#left-navigation-block').animate({
                                    left: '-20%'
                                },{
                                    duration:400,
                                    easing:'swing',
                                    done : function (){      
                                        $(this).attr('data-slide','up');
                                    }
                                });
                                
                                $('#content-layout').animate({left:'-18%',width:'82%'},{duration:400,easing:'swing',done: function (){}});
                                break;
                                
                            case 'up':
                                $('#content-layout').animate({width:'64%',left:'0'},{duration:400,easing:'swing',done: function (){}}); 
                                $('#left-navigation-block').animate({
                                    left: '0%'
                                },{
                                    duration:400,
                                    easing:'swing',
                                    done : function (){
                                        $(this).attr('data-slide','down');
                                    }
                                });
                                break;
                            default:
                                $('#left-navigation-block').animate({
                                    left: '0%'
                                },{
                                    duration:400,
                                    easing:'swing',
                                    done : function (){
                                        $(this).attr('data-slide','down');
                                        $('#content-layout').css({width:'64%'}); 
                                    }
                                });
                                break;
                        }
                            
                    });
                    
                });
                
            })(jQuery);